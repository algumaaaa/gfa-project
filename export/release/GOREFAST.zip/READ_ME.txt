////////////
//GOREFAST//
////////////


W, A, S, D -> TO MOVE
SPACE -> JUMP
", 1, 2, 3, 4, 5 -> SELECT WEAPON
M1 -> KILL


"""""""
CREDITS
"""""""

SFX ARE FROM FREESOUND

SOUNDTRACK BY ME

GUN MODELS

    "Colt 1911" (https://skfb.ly/6nEUA) by AlexChuchvaga is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
    
    "Shotgun" (https://skfb.ly/6VznY) by iedalton is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
    
    "Ingram MAC-10" (https://skfb.ly/6Z8qT) by TheDevilsEye is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
    This work is based on "Ingram MAC-10" (https://sketchfab.com/3d-models/ingram-mac-10-f8bf1f8858734a9f8f613cee406c15c1) by TheDevilsEye (https://sketchfab.com/TheDevilsEye) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)
    
    "low poly lever action rifle" (https://skfb.ly/6WRFX) by fozieus is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
    
    "M79 Grenade launcher" (https://skfb.ly/oow9w) by Digital museum of vietnam war ground equipment is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
    This work is based on "M79 Grenade launcher" (https://sketchfab.com/3d-models/m79-grenade-launcher-7f060586c1f040c5b202eb67ffe0e8e7) by Digital museum of vietnam war ground equipment (https://sketchfab.com/dmovwge) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)

ENEMY MODELS

    "Male Full Body Ecorche" (https://skfb.ly/KFyA) by Diego Luján García is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
    
    "Blob Monster" (https://skfb.ly/6XYWH) by alexalbinyana is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
    "skeleton" (https://skfb.ly/6unHA) by Ludashov Anton is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
    
    "inspiration monster gameart" (https://skfb.ly/WEXM) by liye.yan1994 is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).

FONTS

    Copyright (c) 2013, Quote-Unquote Apps (http://quoteunquoteapps.com/), with Reserved Font Name Courier Prime. This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is copied below, and is also available with a FAQ at: http://scripts.sil.org/OFL
    
    "a Ayo Hemat Tinta Font" Font is made by fontspace.com/wepfont under a FREEWARE lincese